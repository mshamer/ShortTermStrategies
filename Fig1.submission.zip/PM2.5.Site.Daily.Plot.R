# Code for creating Figure 1 in chapter book: Strategies for Using Satellite-based 
# products in Modeling Short-Term Air Quality and Pollution Episodes
# Code development: Mr. Robert Esswein, NASA Ames Research Center/BAERI

## Load libraries-------

library(fields)
library(stringr)

## Create function-------

rle_ext = function(x) {
  
  # Results of rle plus more info; rle: Compute the lengths and values 
  # of runs of equal values in a vector - or the reverse operation
  
  r = rle(x)
  n.run = length(r$lengths)
  start = c(1,1+cumsum(r$lengths[1:(n.run-1)]))
  stop = cumsum(r$lengths)
  list(n.run=n.run,lengths=r$lengths,values=r$values,start=start,stop=stop)
}

## Find the midpoint index-------

midpoint = function(v) {
  n = length(v)
  indx = 1:n
  (v[indx<n] + v[indx>1])/2.
}

## Create a plotting function-------

# This function plots all PM2.5 measurements that were used
# in the regression. The measurements are selected to be within
# a given hour of day range. Therefore, the number of measurements
# per day varies from 1 to 3. This is why the daily X tick marks
# are not evenly distributed.

PM2.5.Site.Daily.Plot = function(PM2.5.RegressionResult) {
  
  # The input "PM2.5.RegressionResult" is a list containing all
  # the inputs to the regression (data and model specification) and
  # the outputs of the regression.
  
  site.data = PM2.5.RegressionResult$site.data
  
  # Coverage plots:
  
  var = 'PM2.5'
  
  # Define range as for predicted maps:
  # There are a few values outside this range
  
  lim.PM2.5 = c(0,75)
  n.time = dim(site.data)[1]
  n.site = dim(site.data)[3]
  
  # Reduce size of large plot, to allow larger Y axis labels
  
  bigplot = c(0.2, 0.85, 0.1457143, 0.8828571)
  titl = str_c(PM2.5.RegressionResult$region,' ',var)
  image.plot(site.data[,var,n.site:1],axes=F,main=titl,zlim=lim.PM2.5,
             bigplot=bigplot)
  
  lim = par('usr')
  ytick = midpoint(seq(lim[3],lim[4],len=n.site+1))
  
  # X axis parameters:
  
  xtick = midpoint(seq(lim[1],lim[2],len=n.time+1))
  wdoytick = rle_ext(site.data[,'DOY',1])$start
  
  # The Mondays:
  
  doydate = ISOdate(site.data[,'year',1],site.data[,'month',1],site.data[,'day',1])
  doydow = as.POSIXlt(doydate)$wday
  tmp = rle_ext(doydow)
  wmonday = tmp$start[tmp$values == 1]
  mondaylab = paste(month.abb[site.data[wmonday,'month',1]],site.data[wmonday,'day',1])
  
  # Modify site names for Y axis labeling:
  
  sitelab = dimnames(site.data)[[3]][n.site:1]
  sitebase = sub('.*_','',sitelab)
  siterle = rle_ext(sitebase)
  
  # Delete prefix from sites with unduplicated base names;
  
  wsingle = siterle$start[siterle$lengths == 1]
  sitelab[wsingle] = sub('^..._','',sitelab[wsingle])
  sitelab[grepl('EPA',sitelab)] = paste(sitebase[grepl('EPA',sitelab)],'E')
  sitelab[grepl('DAQ',sitelab)] = paste(sitebase[grepl('DAQ',sitelab)],'D')
  
  # Draw a point off the plot:
  # This is necessary to get "text" to work.
  
  points(-10,-10)
  
  toffset = -.02
  text(xtick[wmonday],lim[3]+toffset,lab=mondaylab,srt=90,xpd=NA,adj=1,cex=1.1)
  text(lim[1]+toffset,ytick,lab=sitelab,xpd=NA,adj=1,cex=1.1)
  axis(1,at=xtick[wdoytick],label=F,tcl=-.25)
  
  
  NULL
  
}
