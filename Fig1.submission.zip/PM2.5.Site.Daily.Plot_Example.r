#Extract all files

#Set path to files directory
setwd("C:\\Users\\msorekha\\Downloads\\Fig1.submission (1)")

#Install packages (for first time only)
install.packages("fields")
install.packages("stringr")

#Source function
source("PM2.5.Site.Daily.Plot.R")
dat.regress = readRDS("SJV.CWV.CM.hdist.Regress.rds")
PM2.5.Site.Daily.Plot(dat.regress)

