#Example code for Random Forest model (RF)

#setpath to files directory
setwd("C:\\Users\\msorekha\\Documents\\My_Publications\\Under Review\\Env.Inter_Review\\code\\RF-Exmaple")

#Libraries
library(ranger)             # Random forest
library(tidyverse)
library(hydroGOF)           # rmse()
library(caret)              # Train
library(StratifiedMedicine) #Plot importance

#functions
source("plot_importance.R")
source("nrmse_func.R")

df<-readRDS("TestData_RF.rds")


# Hyperparameter tuning
control <- caret::trainControl(method = "repeatedcv", 
                               number = 10, 
                               repeats = 2, 
                               verboseIter = T)


# Train ranger model on tune control (PM2.5 against all variables in the dataset-10-fold CV)
rf_fit_AOD <- train(PM2.5 ~ ., 
                    data = df, 
                    num.trees=1500,
                    method = "ranger",
                    importance = "permutation",
                    trControl=control
)


# Save the model fit and output 
saveRDS(rf_fit_AOD,"PATH FOR SAVING THE FILE\FILENAME.rds")

# Retrieve best model 
model <- rf_fit_AOD$finalModel

# Plot the importance of the paramters
plot_importance(model)+ ggtitle("Importance Daily  AOD-PM2.5")


# Add the predicted value to the main dataframe 
df$predicted<-model$predictions

# Plot the linear regression between observed and predicted

fit_CV1<-lm(predicted~PM2.5,data = df)  #Fitting Linear Model
df$bias<- df$predicted-df$PM2.5  # calcualte the bais
mean(df$bias) #  # calcualte the mean bais

dev<-sigma(fit_CV1)
x1<- coef(fit_CV1)
A1 <- round(signif(x1[1], 3),2)
B1 <- round(signif(x1[-1], 3),2)
Adj.R2.1 <- round(summary(fit_CV1)$adj.r.squared, 2)
N1 <- dim(df)[1] # No. of observations 
Mean1<-round(mean(df$PM2.5,na.rm=TRUE),2)# observed PM2.5 mean 

# Get the Root Mean Square Error between the predicted and the observed
RMSE1 <- round(rmse(df$predicted, df[['PM2.5']]),2)
NRMSE1 <-round(nrmse_func(df[['PM2.5']], df$predicted, type = "mean")*100,2)
MPE1<-round(mean(abs(df$predicted-df$PM2.5), na.rm=T),2)

p1<-plot(df$PM2.5,df$predicted, xlim=c(0.00,500),ylim=c(0.00,500), xlab="",ylab="",pch=19,
         main=paste("R2=",Adj.R2.1,", Slope=",B1,", Intercept=", A1,"\n","RMSE=", RMSE1, 
                    ", N=", N1,"\n",", avg_pm2.5=", Mean1,", NRMSE=",NRMSE1 ))

abline(lm(predicted~PM2.5,data = df),col=2,lwd=2 , lty=1) #Regression line (red)
abline(0,1,lwd=2)                                         #1:1 line (black)


title(xlab=paste("Daily Observed PM2.5")
      ,ylab= paste("Daily Estimated PM2.5"),font.lab=4,cex.lab=1,line = 1.85)


dev.copy(jpeg,width = 7, height = 7, units = 'in', res = 250 , 
         filename=paste("PATH TO SAVE YOUR FIGURE\\RF_Daily_CV.jpg"));
dev.off ()
