plot_importance <- function(model){
  tmp <- model$variable.importance
  dat <- data.frame(variable=names(tmp),importance=tmp)
  ggplot(dat, aes(x=reorder(variable,importance), y=importance))+ 
    geom_bar(stat="identity", position="dodge")+ 
    coord_flip()+
    ylab("Variable Importance")+
    xlab("")
}